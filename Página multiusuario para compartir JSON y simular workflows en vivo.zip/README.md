# Documentación del Proyecto N8N Colaborativo

## Descripción
N8N Colaborativo es una aplicación web multiusuario que permite compartir y editar código JSON de workflows de n8n en tiempo real, con funcionalidades de comunicación mediante chat de texto, audio y video. La aplicación está diseñada para facilitar la colaboración entre equipos que trabajan con n8n, permitiendo visualizar y modificar workflows de manera conjunta.

## Estructura del Proyecto
El proyecto está organizado en dos componentes principales:

### Backend (Flask)
- Gestión de usuarios y autenticación
- API RESTful para workflows y salas
- WebSockets para comunicación en tiempo real
- Almacenamiento de datos (simulado en memoria para esta versión)

### Frontend
- Interfaz de usuario atractiva y responsiva
- Editor de código JSON
- Visualizador de workflows
- Chat de texto en tiempo real
- Videollamadas mediante WebRTC

## Requisitos
- Python 3.11 o superior
- Node.js 20.x o superior
- npm o pnpm

## Instalación

### Backend
1. Navegar al directorio del backend:
```bash
cd proyecto_n8n_colaborativo/backend
```

2. Activar el entorno virtual:
```bash
source venv/bin/activate
```

3. Instalar dependencias:
```bash
pip install -r requirements.txt
```

4. Iniciar el servidor:
```bash
python src/main.py
```
El servidor estará disponible en http://localhost:5000

### Frontend (Opcional - Versión React)
1. Navegar al directorio del frontend:
```bash
cd proyecto_n8n_colaborativo/frontend
```

2. Instalar dependencias:
```bash
npm install
# o
pnpm install
```

3. Iniciar el servidor de desarrollo:
```bash
npm start
# o
pnpm start
```
El frontend estará disponible en http://localhost:3000

## Uso

### Registro e Inicio de Sesión
1. Accede a la aplicación a través de http://localhost:5000
2. Regístrate con un nombre de usuario, email y contraseña
3. Inicia sesión con tus credenciales

### Creación y Edición de Workflows
1. En el dashboard, haz clic en "Crear Workflow"
2. Ingresa un nombre descriptivo y el código JSON del workflow
3. Para editar un workflow existente, haz clic en el icono de edición

### Colaboración en Tiempo Real
1. Crea una sala haciendo clic en "Crear Sala"
2. Selecciona el workflow que deseas compartir
3. Comparte el nombre de la sala con tus colaboradores
4. Los colaboradores pueden unirse a la sala desde la lista de "Salas Activas"
5. Todos los participantes pueden editar el código JSON y ver los cambios en tiempo real

### Comunicación
1. Chat de texto: Escribe mensajes en el panel de chat
2. Videollamada: Activa la cámara y el micrófono con los botones correspondientes
3. Puedes silenciar tu micrófono o desactivar tu cámara según sea necesario

## Características Principales

### Multiusuario
- Registro y autenticación de usuarios
- Perfiles personalizados
- Control de acceso a workflows

### Colaboración en Tiempo Real
- Edición colaborativa de código JSON
- Visualización inmediata de cambios
- Lista de participantes activos

### Comunicación Integrada
- Chat de texto en tiempo real
- Videollamadas con múltiples participantes
- Control de audio y video

### Interfaz Responsiva
- Diseño adaptable a diferentes dispositivos
- Experiencia de usuario intuitiva
- Estilo visual atractivo y profesional

## Notas Técnicas
- La aplicación utiliza WebSockets para la comunicación en tiempo real
- Las videollamadas se implementan mediante WebRTC
- En esta versión, los datos se almacenan en memoria (no persistentes)
- Para un entorno de producción, se recomienda implementar una base de datos

## Solución de Problemas
- Si experimentas problemas con las videollamadas, asegúrate de conceder los permisos de cámara y micrófono
- Para problemas de conexión, verifica que tanto el backend como el frontend estén ejecutándose correctamente
- Si los cambios no se reflejan en tiempo real, intenta actualizar la página o reconectar a la sala

## Próximas Mejoras
- Persistencia de datos con base de datos
- Exportación e importación de workflows
- Historial de cambios y control de versiones
- Más opciones de personalización de la interfaz
