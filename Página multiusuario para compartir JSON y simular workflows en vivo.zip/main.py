import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, render_template, request, jsonify, session
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
from flask_login import LoginManager, current_user, login_user, logout_user, login_required, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
import json
from datetime import datetime
import uuid

# Inicialización de la aplicación Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'clave_secreta_predeterminada')
app.config['JSON_AS_ASCII'] = False

# Configuración de CORS para permitir solicitudes desde el frontend
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

# Inicialización de SocketIO para comunicación en tiempo real
socketio = SocketIO(app, cors_allowed_origins="*")

# Inicialización de LoginManager para autenticación de usuarios
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Base de datos simulada (en producción se usaría una base de datos real)
users_db = {}
workflows_db = {}
active_rooms = {}

# Modelo de Usuario
class User(UserMixin):
    def __init__(self, id, username, email, password_hash):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return self.id

@login_manager.user_loader
def load_user(user_id):
    return users_db.get(user_id)

# Rutas de autenticación
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    
    # Validación básica
    if not username or not email or not password:
        return jsonify({'error': 'Todos los campos son obligatorios'}), 400
    
    # Verificar si el usuario ya existe
    for user in users_db.values():
        if user.username == username or user.email == email:
            return jsonify({'error': 'Usuario o email ya registrado'}), 400
    
    # Crear nuevo usuario
    user_id = str(uuid.uuid4())
    new_user = User(
        id=user_id,
        username=username,
        email=email,
        password_hash=generate_password_hash(password)
    )
    users_db[user_id] = new_user
    
    return jsonify({'message': 'Usuario registrado correctamente', 'user_id': user_id}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    # Validación básica
    if not email or not password:
        return jsonify({'error': 'Email y contraseña son obligatorios'}), 400
    
    # Buscar usuario por email
    user = None
    for u in users_db.values():
        if u.email == email:
            user = u
            break
    
    # Verificar credenciales
    if user and user.check_password(password):
        login_user(user)
        return jsonify({
            'message': 'Inicio de sesión exitoso',
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email
            }
        }), 200
    
    return jsonify({'error': 'Credenciales inválidas'}), 401

@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'Sesión cerrada correctamente'}), 200

@app.route('/api/user', methods=['GET'])
@login_required
def get_user():
    return jsonify({
        'id': current_user.id,
        'username': current_user.username,
        'email': current_user.email
    }), 200

# Rutas para workflows y JSON
@app.route('/api/workflows', methods=['GET'])
@login_required
def get_workflows():
    return jsonify(list(workflows_db.values())), 200

@app.route('/api/workflows', methods=['POST'])
@login_required
def create_workflow():
    data = request.get_json()
    name = data.get('name')
    json_data = data.get('json_data')
    
    if not name or not json_data:
        return jsonify({'error': 'Nombre y datos JSON son obligatorios'}), 400
    
    workflow_id = str(uuid.uuid4())
    workflow = {
        'id': workflow_id,
        'name': name,
        'json_data': json_data,
        'creator_id': current_user.id,
        'creator_name': current_user.username,
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat()
    }
    
    workflows_db[workflow_id] = workflow
    return jsonify(workflow), 201

@app.route('/api/workflows/<workflow_id>', methods=['GET'])
@login_required
def get_workflow(workflow_id):
    workflow = workflows_db.get(workflow_id)
    if not workflow:
        return jsonify({'error': 'Workflow no encontrado'}), 404
    
    return jsonify(workflow), 200

@app.route('/api/workflows/<workflow_id>', methods=['PUT'])
@login_required
def update_workflow(workflow_id):
    workflow = workflows_db.get(workflow_id)
    if not workflow:
        return jsonify({'error': 'Workflow no encontrado'}), 404
    
    data = request.get_json()
    name = data.get('name')
    json_data = data.get('json_data')
    
    if name:
        workflow['name'] = name
    if json_data:
        workflow['json_data'] = json_data
    
    workflow['updated_at'] = datetime.now().isoformat()
    workflows_db[workflow_id] = workflow
    
    # Notificar a todos los usuarios en la sala sobre la actualización
    socketio.emit('workflow_updated', workflow, room=f'workflow_{workflow_id}')
    
    return jsonify(workflow), 200

@app.route('/api/workflows/<workflow_id>', methods=['DELETE'])
@login_required
def delete_workflow(workflow_id):
    if workflow_id not in workflows_db:
        return jsonify({'error': 'Workflow no encontrado'}), 404
    
    # Verificar si el usuario actual es el creador
    if workflows_db[workflow_id]['creator_id'] != current_user.id:
        return jsonify({'error': 'No tienes permiso para eliminar este workflow'}), 403
    
    del workflows_db[workflow_id]
    return jsonify({'message': 'Workflow eliminado correctamente'}), 200

# Rutas para salas de colaboración
@app.route('/api/rooms', methods=['GET'])
@login_required
def get_rooms():
    return jsonify(list(active_rooms.values())), 200

@app.route('/api/rooms', methods=['POST'])
@login_required
def create_room():
    data = request.get_json()
    name = data.get('name')
    workflow_id = data.get('workflow_id')
    
    if not name or not workflow_id:
        return jsonify({'error': 'Nombre y ID de workflow son obligatorios'}), 400
    
    if workflow_id not in workflows_db:
        return jsonify({'error': 'Workflow no encontrado'}), 404
    
    room_id = str(uuid.uuid4())
    room = {
        'id': room_id,
        'name': name,
        'workflow_id': workflow_id,
        'creator_id': current_user.id,
        'creator_name': current_user.username,
        'created_at': datetime.now().isoformat(),
        'participants': [
            {
                'id': current_user.id,
                'username': current_user.username
            }
        ]
    }
    
    active_rooms[room_id] = room
    return jsonify(room), 201

# Eventos de Socket.IO
@socketio.on('connect')
def handle_connect():
    if current_user.is_authenticated:
        emit('connection_success', {'user_id': current_user.id, 'username': current_user.username})
    else:
        emit('connection_error', {'error': 'No autenticado'})

@socketio.on('join_room')
def handle_join_room(data):
    room_id = data.get('room_id')
    if not room_id or room_id not in active_rooms:
        emit('error', {'error': 'Sala no encontrada'})
        return
    
    join_room(room_id)
    
    # Añadir usuario a la lista de participantes si no está ya
    room = active_rooms[room_id]
    user_exists = False
    for participant in room['participants']:
        if participant['id'] == current_user.id:
            user_exists = True
            break
    
    if not user_exists:
        room['participants'].append({
            'id': current_user.id,
            'username': current_user.username
        })
    
    # Notificar a todos los usuarios en la sala
    emit('user_joined', {
        'user_id': current_user.id,
        'username': current_user.username,
        'room_id': room_id
    }, room=room_id)
    
    # Enviar la lista actualizada de participantes
    emit('participants_updated', {
        'participants': room['participants']
    }, room=room_id)

@socketio.on('leave_room')
def handle_leave_room(data):
    room_id = data.get('room_id')
    if not room_id or room_id not in active_rooms:
        emit('error', {'error': 'Sala no encontrada'})
        return
    
    leave_room(room_id)
    
    # Eliminar usuario de la lista de participantes
    room = active_rooms[room_id]
    room['participants'] = [p for p in room['participants'] if p['id'] != current_user.id]
    
    # Notificar a todos los usuarios en la sala
    emit('user_left', {
        'user_id': current_user.id,
        'username': current_user.username,
        'room_id': room_id
    }, room=room_id)
    
    # Enviar la lista actualizada de participantes
    emit('participants_updated', {
        'participants': room['participants']
    }, room=room_id)
    
    # Si no quedan participantes, eliminar la sala
    if not room['participants']:
        del active_rooms[room_id]

@socketio.on('send_message')
def handle_send_message(data):
    room_id = data.get('room_id')
    message = data.get('message')
    
    if not room_id or not message or room_id not in active_rooms:
        emit('error', {'error': 'Datos inválidos o sala no encontrada'})
        return
    
    message_data = {
        'id': str(uuid.uuid4()),
        'user_id': current_user.id,
        'username': current_user.username,
        'message': message,
        'timestamp': datetime.now().isoformat()
    }
    
    emit('new_message', message_data, room=room_id)

@socketio.on('update_json')
def handle_update_json(data):
    room_id = data.get('room_id')
    workflow_id = data.get('workflow_id')
    json_data = data.get('json_data')
    
    if not room_id or not workflow_id or not json_data:
        emit('error', {'error': 'Datos inválidos'})
        return
    
    if room_id not in active_rooms or workflow_id not in workflows_db:
        emit('error', {'error': 'Sala o workflow no encontrado'})
        return
    
    # Actualizar el workflow
    workflow = workflows_db[workflow_id]
    workflow['json_data'] = json_data
    workflow['updated_at'] = datetime.now().isoformat()
    
    # Notificar a todos los usuarios en la sala
    emit('json_updated', {
        'workflow_id': workflow_id,
        'json_data': json_data,
        'updated_by': {
            'id': current_user.id,
            'username': current_user.username
        },
        'updated_at': workflow['updated_at']
    }, room=room_id)

@socketio.on('signal')
def handle_signal(data):
    room_id = data.get('room_id')
    target_id = data.get('target_id')
    signal_data = data.get('signal')
    
    if not room_id or not target_id or not signal_data:
        emit('error', {'error': 'Datos inválidos'})
        return
    
    # Reenviar la señal al usuario objetivo
    emit('signal', {
        'from_id': current_user.id,
        'from_username': current_user.username,
        'signal': signal_data
    }, room=target_id)

# Ruta principal para servir la aplicación
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
