import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import './App.css';

interface User {
  id: string;
  username: string;
  email: string;
}

interface Workflow {
  id: string;
  name: string;
  json_data: any;
  creator_id: string;
  creator_name: string;
  created_at: string;
  updated_at: string;
}

interface Room {
  id: string;
  name: string;
  workflow_id: string;
  creator_id: string;
  creator_name: string;
  created_at: string;
  participants: Participant[];
}

interface Participant {
  id: string;
  username: string;
}

interface Message {
  id: string;
  user_id: string;
  username: string;
  message: string;
  timestamp: string;
}

interface PeerConnection {
  connection: RTCPeerConnection;
  dataChannel?: RTCDataChannel;
}

const App: React.FC = () => {
  // Estados
  const [user, setUser] = useState<User | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [showRegister, setShowRegister] = useState<boolean>(false);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [currentWorkflow, setCurrentWorkflow] = useState<Workflow | null>(null);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
  const [activeSection, setActiveSection] = useState<string>('dashboard');
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState<string>('');
  const [jsonEditorContent, setJsonEditorContent] = useState<string>('');
  
  // Formularios
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ username: '', email: '', password: '' });
  const [workflowForm, setWorkflowForm] = useState({ name: '', json_data: '' });
  const [roomForm, setRoomForm] = useState({ name: '', workflow_id: '' });
  
  // WebRTC
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [isVideoEnabled, setIsVideoEnabled] = useState<boolean>(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState<boolean>(true);
  const peerConnections = useRef<Record<string, PeerConnection>>({});
  
  // Socket.io
  const socketRef = useRef<Socket | null>(null);
  const chatMessagesRef = useRef<HTMLDivElement>(null);
  
  // Efectos
  useEffect(() => {
    // Verificar si el usuario está autenticado
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        setIsLoggedIn(true);
        loadWorkflows();
        loadRooms();
      } catch (error) {
        console.error('Error parsing user from localStorage:', error);
        localStorage.removeItem('user');
      }
    }
  }, []);
  
  useEffect(() => {
    // Scroll al final del chat cuando hay nuevos mensajes
    if (chatMessagesRef.current) {
      chatMessagesRef.current.scrollTop = chatMessagesRef.current.scrollHeight;
    }
  }, [messages]);
  
  // Funciones de autenticación
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(loginForm),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (response.ok) {
        localStorage.setItem('user', JSON.stringify(data.user));
        setUser(data.user);
        setIsLoggedIn(true);
        loadWorkflows();
        loadRooms();
      } else {
        alert(data.error || 'Error al iniciar sesión');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(registerForm)
      });
      
      const data = await response.json();
      
      if (response.ok) {
        alert('Registro exitoso. Ahora puedes iniciar sesión.');
        setShowRegister(false);
        setRegisterForm({ username: '', email: '', password: '' });
      } else {
        alert(data.error || 'Error al registrarse');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  const handleLogout = async () => {
    try {
      const response = await fetch('/api/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        localStorage.removeItem('user');
        setUser(null);
        setIsLoggedIn(false);
        
        // Cerrar conexiones
        if (socketRef.current) {
          socketRef.current.disconnect();
          socketRef.current = null;
        }
        
        stopVideoChat();
      } else {
        const data = await response.json();
        alert(data.error || 'Error al cerrar sesión');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  // Funciones de carga de datos
  const loadWorkflows = async () => {
    try {
      const response = await fetch('/api/workflows', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setWorkflows(data);
      } else {
        console.error('Error al cargar workflows');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  
  const loadRooms = async () => {
    try {
      const response = await fetch('/api/rooms', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setRooms(data);
      } else {
        console.error('Error al cargar salas');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  
  // Funciones de workflows
  const createWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Validar JSON
      let parsedJson;
      try {
        parsedJson = JSON.parse(workflowForm.json_data);
      } catch (e) {
        alert('El JSON ingresado no es válido');
        return;
      }
      
      const response = await fetch('/api/workflows', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: workflowForm.name,
          json_data: parsedJson
        }),
        credentials: 'include'
      });
      
      if (response.ok) {
        alert('Workflow creado correctamente');
        setWorkflowForm({ name: '', json_data: '' });
        loadWorkflows();
        setActiveSection('dashboard');
      } else {
        const data = await response.json();
        alert(data.error || 'Error al crear workflow');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  const updateWorkflow = async () => {
    if (!currentWorkflow) {
      alert('No hay workflow seleccionado');
      return;
    }
    
    try {
      // Validar JSON
      let parsedJson;
      try {
        parsedJson = JSON.parse(jsonEditorContent);
      } catch (e) {
        alert('El JSON ingresado no es válido');
        return;
      }
      
      const response = await fetch(`/api/workflows/${currentWorkflow.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          json_data: parsedJson
        }),
        credentials: 'include'
      });
      
      if (response.ok) {
        alert('Workflow actualizado correctamente');
        
        // Actualizar workflow local
        setCurrentWorkflow({
          ...currentWorkflow,
          json_data: parsedJson
        });
        
        // Si estamos en una sala, notificar a los demás
        if (currentRoom && socketRef.current) {
          socketRef.current.emit('update_json', {
            room_id: currentRoom.id,
            workflow_id: currentWorkflow.id,
            json_data: parsedJson
          });
        }
        
        loadWorkflows();
      } else {
        const data = await response.json();
        alert(data.error || 'Error al actualizar workflow');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  const deleteWorkflow = async (id: string) => {
    if (!confirm('¿Estás seguro de que deseas eliminar este workflow?')) {
      return;
    }
    
    try {
      const response = await fetch(`/api/workflows/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        alert('Workflow eliminado correctamente');
        loadWorkflows();
      } else {
        const data = await response.json();
        alert(data.error || 'Error al eliminar workflow');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  const openWorkflow = (workflow: Workflow) => {
    setCurrentWorkflow(workflow);
    setJsonEditorContent(JSON.stringify(workflow.json_data, null, 2));
    setActiveSection('edit-workflow');
  };
  
  // Funciones de salas
  const createRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/rooms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(roomForm),
        credentials: 'include'
      });
      
      if (response.ok) {
        const room = await response.json();
        alert('Sala creada correctamente');
        setRoomForm({ name: '', workflow_id: '' });
        loadRooms();
        joinRoom(room);
      } else {
        const data = await response.json();
        alert(data.error || 'Error al crear sala');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al conectar con el servidor');
    }
  };
  
  const joinRoom = async (room: Room) => {
    setCurrentRoom(room);
    
    try {
      const response = await fetch(`/api/workflows/${room.workflow_id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        const workflow = await response.json();
        setCurrentWorkflow(workflow);
        setJsonEditorContent(JSON.stringify(workflow.json_data, null, 2));
        
        // Limpiar chat y participantes
        setMessages([]);
        setParticipants([]);
        
        // Conectar a la sala via Socket.IO
        connectToRoom(room.id);
        
        setActiveSection('edit-workflow');
      } else {
        alert('Error al cargar el workflow');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al cargar el workflow');
    }
  };
  
  // Socket.IO
  const connectToRoom = (roomId: string) => {
    // Inicializar Socket.IO si no existe
    if (!socketRef.current) {
      socketRef.current = io();
      
      socketRef.current.on('connect', () => {
        console.log('Conectado a Socket.IO');
      });
      
      socketRef.current.on('connection_error', (data: { error: string }) => {
        console.error('Error de conexión:', data.error);
        alert('Error de conexión: ' + data.error);
      });
      
      socketRef.current.on('user_joined', (data: { user_id: string, username: string, room_id: string }) => {
        console.log('Usuario unido:', data);
        // Iniciar conexión WebRTC si no es el usuario actual
        if (data.user_id !== user?.id && localStream) {
          createPeerConnection(data.user_id);
        }
      });
      
      socketRef.current.on('user_left', (data: { user_id: string, username: string, room_id: string }) => {
        console.log('Usuario salió:', data);
        // Cerrar conexión WebRTC
        if (peerConnections.current[data.user_id]) {
          peerConnections.current[data.user_id].connection.close();
          delete peerConnections.current[data.user_id];
        }
      });
      
      socketRef.current.on('participants_updated', (data: { participants: Participant[] }) => {
        console.log('Participantes actualizados:', data);
        setParticipants(data.participants);
      });
      
      socketRef.current.on('new_message', (data: Message) => {
        console.log('Nuevo mensaje:', data);
        setMessages(prev => [...prev, data]);
      });
      
      socketRef.current.on('json_updated', (data: { workflow_id: string, json_data: any }) => {
        console.log('JSON actualizado:', data);
        if (currentWorkflow && data.workflow_id === currentWorkflow.id) {
          setJsonEditorContent(JSON.stringify(data.json_data, null, 2));
          setCurrentWorkflow(prev => prev ? { ...prev, json_data: data.json_data } : null);
        }
      });
      
      socketRef.current.on('signal', (data: { from_id: string, from_username: string, signal: any }) => {
        console.log('Señal recibida:', data);
        handleSignal(data);
      });
    }
    
    // Unirse a la sala
    socketRef.current.emit('join_room', { room_id: roomId });
  };
  
  const sendMessage = () => {
    if (!newMessage.trim() || !currentRoom || !socketRef.current) {
      return;
    }
    
    socketRef.current.emit('send_message', {
      room_id: currentRoom.id,
      message: newMessage
    });
    
    setNewMessage('');
  };
  
  // WebRTC
  const startVideoChat = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setLocalStream(stream);
      setIsVideoEnabled(true);
      setIsAudioEnabled(true);
      
      // Iniciar conexiones con participantes existentes
      participants.forEach(participant => {
        if (participant.id !== user?.id) {
          createPeerConnection(participant.id);
        }
      });
    } catch (error) {
      console.error('Error al acceder a la cámara y micrófono:', error);
      alert('Error al acceder a la cámara y micrófono. Asegúrate de conceder los permisos necesarios.');
    }
  };
  
  const stopVideoChat = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    
    // Cerrar todas las conexiones peer
    Object.values(peerConnections.current).forEach(pc => pc.connection.close());
    peerConnections.current = {};
  };
  
  const toggleVideo = () => {
    if (!localStream) {
      startVideoChat();
      return;
    }
    
    const videoTrack = localStream.getVideoTracks()[0];
    if (videoTrack) {
      videoTrack.enabled = !videoTrack.enabled;
      setIsVideoEnabled(videoTrack.enabled);
    }
  };
  
  const toggleAudio = () => {
    if (!localStream) {
      startVideoChat();
      return;
    }
    
    const audioTrack = localStream.getAudioTracks()[0];
    if (audioTrack) {
      audioTrack.enabled = !audioTrack.enabled;
      setIsAudioEnabled(audioTrack.enabled);
    }
  };
  
  const createPeerConnection = (peerId: string) => {
    if (peerConnections.current[peerId]) {
      console.log('Conexión ya existente para:', peerId);
 
(Content truncated due to size limit. Use line ranges to read in chunks)